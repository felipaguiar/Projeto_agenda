﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Agenda_telefonica
{
    public static class cl_princial
    {
        public static string versao = "Projeto V1";

        //lista de contatos
        public static List<lista_cont> LISTA_CONT;


        public static void ListaConstatos()
        {
            string pasta = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string notepad = pasta + "\\contatos.txt";
            //criando o txt
            LISTA_CONT = new List<lista_cont>();

            if (File.Exists(notepad))
            {
                StreamReader notepad2 = new StreamReader(notepad, Encoding.Default);
                while (!notepad2.EndOfStream)
                {
                    string nome = notepad2.ReadLine();

                    string endereco = notepad2.ReadLine();

                    string telefone = notepad2.ReadLine();

                    lista_cont nova_lista = new lista_cont();
                    nova_lista.nome = nome;
                    nova_lista.endereco = endereco;
                    nova_lista.telefone = telefone;
                    LISTA_CONT.Add(nova_lista);
                }
                notepad2.Dispose();
            }
        }

        public static void Adicionar (string nome2, string endereco2, string telefone2)
        {


            //adicionando na lista
            LISTA_CONT.Add(new lista_cont() { nome = nome2, endereco = endereco2, telefone = telefone2 });

            //atualizando a lista
            AddTXT();
        }
        public static void AddTXT()
        {
            string pasta = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string notepad = pasta + "\\contatos.txt";

            StreamWriter notepad2 = new StreamWriter(notepad, false, Encoding.Default);
            foreach(lista_cont lista in LISTA_CONT)
            {
                notepad2.WriteLine(lista.nome);
                notepad2.WriteLine(lista.endereco);
                notepad2.WriteLine(lista.telefone);
            }
            notepad2.Dispose();
        }
        

    }

    
}
