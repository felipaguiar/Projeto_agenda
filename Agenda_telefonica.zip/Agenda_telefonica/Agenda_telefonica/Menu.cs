﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda_telefonica
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();

            //mostrando os contatos
            cl_princial.ListaConstatos();

            lblVersao.Text = cl_princial.versao;
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            //sair da agenda
            if (MessageBox.Show("Deseja realmente sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No) return;

            //sair
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //após clicar no botão adicionar e editar aparecer o novo formulário
            form_add_editar form = new form_add_editar();
            form.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
