﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Agenda_telefonica
{
    public partial class form_add_editar : Form
    {
        int ind;
        private readonly object Geral;

        public form_add_editar()
        {
            InitializeComponent();
            ListaConstroi();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();

        }
        private void ListaConstroi()
        {
            //add a lista de registro
            listCont.Items.Clear();

            foreach(lista_cont lista in cl_princial.LISTA_CONT)
            {
                listCont.Items.Add("Nome: " + lista.nome + " Endereço: " + lista.endereco + " Telefone: " + lista.telefone);
            }

            //quantidade de registro
            lblQtd.Text = "Numero de registros: " + listCont.Items.Count;

            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if(txtNome.Text == "" || txtEnd.Text == "" || txtNumero.Text == "")
            {
                MessageBox.Show("Os campos não estão preenchidos");
                return;
            }
            foreach(lista_cont lista in cl_princial.LISTA_CONT)
            {
                if(lista.nome == txtNome.Text && lista.endereco == txtEnd.Text && lista.telefone == txtNumero.Text)
                {
                    MessageBox.Show("Dados já existente!");
                    return;
                }
            }
            cl_princial.Adicionar(txtNome.Text, txtEnd.Text, txtNumero.Text);

            ListaConstroi();

            txtNome.Text = "";
            txtEnd.Text = "";
            txtNumero.Text = "";
            txtNome.Focus();
        }

        private void listCont_SelectedIndexChanged(object sender, EventArgs e)
        {
            //selecionando o contato
            if (listCont.SelectedIndex == -1) return;

            ind = listCont.SelectedIndex;

            btnEditar.Enabled = true;
            btnExcluir.Enabled = true;

            txtNome.Text = cl_princial.LISTA_CONT[ind].nome;
            txtEnd.Text = cl_princial.LISTA_CONT[ind].endereco;
            txtNumero.Text = cl_princial.LISTA_CONT[ind].telefone;

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            //apagando contato selecionado

            //primeira parte é eliminar o contato
            cl_princial.LISTA_CONT.RemoveAt(ind);

            //segunda parte é renotar a lista
            cl_princial.AddTXT();

            //terceira parte é recontruir a lista
            ListaConstroi();
            txtNome.Text = "";
            txtEnd.Text = "";
            txtNumero.Text = "";
            txtNome.Focus();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            cl_princial.LISTA_CONT[ind].nome = txtNome.Text;
            cl_princial.LISTA_CONT[ind].endereco = txtEnd.Text;
            cl_princial.LISTA_CONT[ind].telefone = txtNumero.Text;
            ListaConstroi();
            cl_princial.AddTXT();
            txtNome.Text = "";
            txtEnd.Text = "";
            txtNumero.Text = "";
            txtNome.Focus();
        }

        
    }
}
