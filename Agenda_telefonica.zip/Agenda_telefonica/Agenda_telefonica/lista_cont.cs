﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agenda_telefonica
{
    public class lista_cont
    {
        public string nome { get; set; }
        public string endereco { get; set; }
        public string telefone { get; set; }

        internal static void Add()
        {
            throw new NotImplementedException();
        }
    }
}
